# Content

- **Datasets** containing up-to-date data (through July 2025) on **reported crimes (2022–2024) in Rio Grande do Sul (Brazil)**. Used for learning data science in Python, the datasets cover the reported crimes, their circumstances, and some anonymized victim attributes.

# References

- RIO GRANDE DO SUL. **Dados Abertos (Lei no 15.610/2021)**. Secretaria de Segurança Pública, \[2025]. Disponível em: <https://www.ssp.rs.gov.br/dados-abertos>. Acesso em: 15 jul. 2025.
